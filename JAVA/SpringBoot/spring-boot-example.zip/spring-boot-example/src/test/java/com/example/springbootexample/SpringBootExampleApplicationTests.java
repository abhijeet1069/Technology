package com.example.springbootexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
